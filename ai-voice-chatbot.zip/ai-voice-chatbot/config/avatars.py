"""
Avatar configurations for the chatbot
"""

AVATARS = {
    "😊 Friendly": {
        "emoji": "😊",
        "color": "#FFB6C6",
        "description": "A warm and friendly personality",
        "greeting": "Hello! I'm your friendly assistant!",
    },
    "🤖 Robot": {
        "emoji": "🤖",
        "color": "#87CEEB",
        "description": "A logical and precise AI",
        "greeting": "Beep boop! Ready to assist.",
    },
    "👨‍💼 Professional": {
        "emoji": "👨‍💼",
        "color": "#4169E1",
        "description": "A professional business assistant",
        "greeting": "Good day! How may I assist you?",
    },
    "👩‍💻 Tech Expert": {
        "emoji": "👩‍💻",
        "color": "#9370DB",
        "description": "A tech-savvy expert",
        "greeting": "Hey! Ready to debug life? 😄",
    },
    "🧙‍♂️ Wizard": {
        "emoji": "🧙‍♂️",
        "color": "#FFD700",
        "description": "A mystical wizard",
        "greeting": "Greetings, seeker of knowledge!",
    },
    "🎨 Creative": {
        "emoji": "🎨",
        "color": "#FF69B4",
        "description": "A creative and artistic soul",
        "greeting": "Let's create something amazing!",
    },
}

def get_avatar(name):
    """Get avatar details by name"""
    return AVATARS.get(name, AVATARS["😊 Friendly"])

def get_avatar_list():
    """Get list of available avatars"""
    return list(AVATARS.keys())
