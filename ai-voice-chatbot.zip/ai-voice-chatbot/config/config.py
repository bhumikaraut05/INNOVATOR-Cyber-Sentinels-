"""
Configuration file for AI Voice Chatbot
"""

import os
from datetime import datetime

# Project paths
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(PROJECT_ROOT, "data")
LOGS_DIR = os.path.join(PROJECT_ROOT, "logs")
CONFIG_DIR = os.path.join(PROJECT_ROOT, "config")

# Create directories if they don't exist
for directory in [DATA_DIR, LOGS_DIR]:
    os.makedirs(directory, exist_ok=True)

# Logging configuration
LOG_FILE = os.path.join(LOGS_DIR, f"chatbot_{datetime.now().strftime('%Y%m%d')}.log")
LOG_LEVEL = "INFO"
LOG_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"

# Voice configuration
VOICE_RATE = 150  # Words per minute
VOICE_TIMEOUT = 10  # Seconds to listen
VOICE_LANGUAGE = "en-US"

# Chat configuration
DEFAULT_BOT_NAME = "AI Assistant"
MAX_CONVERSATION_LENGTH = 100  # Max messages to keep in memory
CHAT_HISTORY_FILE = os.path.join(DATA_DIR, "chat_history.json")

# Streamlit configuration
APP_TITLE = "AI Voice Chatbot"
APP_ICON = "🤖"
PAGE_LAYOUT = "wide"
INITIAL_SIDEBAR_STATE = "expanded"

# Feature flags
ENABLE_VOICE_INPUT = True
ENABLE_VOICE_OUTPUT = True
ENABLE_CHAT_HISTORY = True
ENABLE_SENTIMENT_ANALYSIS = True
OFFLINE_MODE = True  # No API key required

# OpenAI API (optional)
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
OPENAI_MODEL = "gpt-3.5-turbo"
OPENAI_TEMPERATURE = 0.7
OPENAI_MAX_TOKENS = 500

print(f"Config loaded from: {CONFIG_DIR}")
