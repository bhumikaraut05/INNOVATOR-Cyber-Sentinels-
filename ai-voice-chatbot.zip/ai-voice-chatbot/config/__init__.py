"""
Configuration module for AI Voice Chatbot
"""

from .config import *
from .avatars import *
from .knowledge_base import *
