"""
Knowledge base for offline responses
"""

from datetime import datetime

def get_knowledge_base():
    """Get dynamic knowledge base with current time/date"""
    return {
        # Greetings
        "hello": "Hello! How can I help you today?",
        "hi": "Hey there! What can I do for you?",
        "howdy": "Howdy! What's up?",
        "hey": "Hey! What's on your mind?",
        
        # Personal
        "how are you": "I'm doing great, thanks for asking! How about you?",
        "your name": "I'm your AI Voice Assistant!",
        "who are you": "I'm an intelligent chatbot designed to help you!",
        
        # Time & Date
        "what time": f"It's currently {datetime.now().strftime('%I:%M %p')}",
        "time": f"The time is {datetime.now().strftime('%I:%M %p')}",
        "date": f"Today is {datetime.now().strftime('%A, %B %d, %Y')}",
        "today": f"Today is {datetime.now().strftime('%A, %B %d, %Y')}",
        
        # General knowledge
        "weather": "I don't have internet access, but I hope the weather is nice where you are!",
        "joke": "Why did the AI go to school? To improve its learning model! 😄",
        "another joke": "Why do programmers prefer dark mode? Because light attracts bugs! 🐛",
        "help": "I can chat with you, answer questions, tell jokes, and use voice commands!",
        
        # Gratitude
        "thanks": "You're welcome! Let me know if you need anything else!",
        "thank you": "Happy to help! Anything else?",
        "thankyou": "My pleasure!",
        
        # Farewell
        "goodbye": "Take care! It was nice talking to you! 👋",
        "bye": "See you later! Bye! 👋",
        "see you": "See you soon! Take care!",
        
        # Topics
        "python": "Python is a fantastic programming language! Great for AI and ML!",
        "programming": "Programming is fun! What language do you prefer?",
        "ai": "Artificial Intelligence is the future! I love talking about AI!",
        "machine learning": "Machine Learning is amazing! It powers modern AI!",
        "data science": "Data Science is fascinating! It's all about finding patterns!",
        "music": "Music is wonderful! What's your favorite genre?",
        "movies": "Movies are great! What's your favorite movie?",
        "sports": "Sports are exciting! Do you have a favorite sport?",
        "books": "Books are amazing! What's your favorite book?",
        "travel": "Travel is wonderful! Have you been anywhere exciting?",
        
        # Emotions
        "love": "That's great! Love is wonderful! 💕",
        "sad": "I'm sorry to hear that. Things will get better! Stay positive! 💪",
        "happy": "That's wonderful! Keep smiling! 😊",
        "excited": "That's awesome! Excitement is contagious! 🎉",
        "angry": "Stay calm! Take a deep breath. Things will improve!",
        
        # Questions
        "what can you do": "I can chat with you, recognize your voice, speak responses, and help with various topics!",
        "how does this work": "I use speech recognition to understand you and generate smart responses!",
        "are you real": "I'm an AI assistant, so I'm real in the digital sense! 😄",
        
        # Popular
        "hello world": "Hello World! Classic programming! 🎉",
        "test": "I'm working perfectly! What can I help you with?",
        "hi there": "Hi! I'm here and ready to help!",
    }

def get_response(user_input):
    """Get response from knowledge base"""
    kb = get_knowledge_base()
    user_lower = user_input.lower().strip()
    
    # Exact match
    if user_lower in kb:
        return kb[user_lower]
    
    # Partial match
    for key, response in kb.items():
        if key in user_lower:
            return response
    
    return None
