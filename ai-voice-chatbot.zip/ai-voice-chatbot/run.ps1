# Start AI Voice Chatbot
Write-Host "🤖 Starting AI Voice Chatbot..." -ForegroundColor Cyan
Write-Host "Please wait..." -ForegroundColor Yellow

python -m streamlit run app.py

Read-Host "Press Enter to close"
