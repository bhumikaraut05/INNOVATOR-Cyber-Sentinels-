"""
Unit tests for AI Voice Chatbot
"""

import unittest
from config.knowledge_base import get_response, get_knowledge_base
from utils.chat import get_ai_response, is_greeting, is_farewell

class TestKnowledgeBase(unittest.TestCase):
    """Test knowledge base responses"""
    
    def test_greeting_response(self):
        """Test greeting responses"""
        response = get_response("hello")
        self.assertIsNotNone(response)
    
    def test_joke_response(self):
        """Test joke response"""
        response = get_response("joke")
        self.assertIsNotNone(response)
    
    def test_time_response(self):
        """Test time response"""
        response = get_response("what time")
        self.assertIsNotNone(response)
        self.assertIn(":", response)  # Should contain time format

class TestChatFunctions(unittest.TestCase):
    """Test chat utility functions"""
    
    def test_greeting_detection(self):
        """Test greeting detection"""
        self.assertTrue(is_greeting("hello"))
        self.assertTrue(is_greeting("Hi there"))
        self.assertFalse(is_greeting("goodbye"))
    
    def test_farewell_detection(self):
        """Test farewell detection"""
        self.assertTrue(is_farewell("goodbye"))
        self.assertTrue(is_farewell("bye"))
        self.assertFalse(is_farewell("hello"))

class TestAIResponse(unittest.TestCase):
    """Test AI response generation"""
    
    def test_response_generation(self):
        """Test response generation"""
        response = get_ai_response("Hello")
        self.assertIsNotNone(response)
        self.assertIsInstance(response, str)
        self.assertGreater(len(response), 0)

if __name__ == "__main__":
    unittest.main()
