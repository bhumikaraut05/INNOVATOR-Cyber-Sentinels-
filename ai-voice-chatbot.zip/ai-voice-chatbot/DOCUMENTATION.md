# 🤖 AI Voice Chatbot - Complete Documentation

## Table of Contents
1. [Overview](#overview)
2. [Features](#features)
3. [Installation](#installation)
4. [Usage](#usage)
5. [Configuration](#configuration)
6. [Architecture](#architecture)
7. [API Reference](#api-reference)
8. [Troubleshooting](#troubleshooting)
9. [Contributing](#contributing)

---

## Overview

**AI Voice Chatbot v2.0** is a free, offline AI assistant with voice I/O capabilities built with Streamlit. No API keys required!

### Key Highlights
- ✅ **Completely Free** - No costs
- ✅ **Offline Mode** - Works without internet
- ✅ **Voice I/O** - Listen and speak
- ✅ **6 Avatars** - Choose your personality
- ✅ **Chat Memory** - Remembers conversations
- ✅ **No API Key** - Zero configuration needed

---

## Features

### 🎤 Voice Features
- **Voice Input**: Speak naturally, bot understands you
- **Voice Output**: Bot speaks responses back
- **Adjustable Speed**: Control voice speed (0.5x - 2.0x)
- **Microphone Check**: Detects if microphone is available

### 💬 Chat Features
- **Intelligent Responses**: Sentiment analysis for context-aware responses
- **Knowledge Base**: 50+ pre-programmed responses
- **Chat History**: Saves and loads conversation history
- **Multiple Avatars**: 6 different personality styles
- **Custom Bot Name**: Personalize your assistant

### 🎛️ Configuration
- **Voice Speed Control**: Adjust speech rate
- **Auto-Speak Toggle**: Turn voice output on/off
- **Voice Input Toggle**: Enable/disable microphone
- **Avatar Selection**: Choose from 6 avatars
- **Custom Bot Name**: Give your bot a unique name

### 📊 Data Management
- **Chat History**: Auto-saves conversations
- **Statistics**: View conversation metrics
- **Export**: Save chat logs
- **Clear History**: One-click chat clearing

---

## Installation

### Windows Quick Start

#### Option 1: Auto Setup (Recommended)
1. Double-click `setup.bat` in the project folder
2. Wait for installation to complete
3. Run with: Double-click `run.bat`

#### Option 2: Manual Setup
```bash
# Open Command Prompt or PowerShell in project folder
python -m venv venv
venv\Scripts\activate.bat
pip install -r requirements.txt
streamlit run app.py
```

### macOS / Linux Quick Start

```bash
# Terminal commands
chmod +x setup.sh
./setup.sh
source venv/bin/activate
streamlit run app.py
```

### Requirements
- Python 3.8+
- pip (Python package manager)
- Microphone (for voice input)
- ~200MB disk space

---

## Usage

### Starting the App

**Windows:**
- Double-click `run.bat`

**macOS/Linux:**
```bash
source venv/bin/activate
streamlit run app.py
```

### First Run

1. **Choose Avatar**: Select from 6 personality types in left sidebar
2. **Name Your Bot**: Give your bot a custom name
3. **Adjust Voice**: Use slider to set speech speed
4. **Enable Voice**: Check "Enable voice input" if you have a mic
5. **Start Chatting**: Type or speak to your bot!

### Example Commands

```bash
👤 You: Hello!
🤖 Bot: Hello! How can I help you today?

👤 You: Tell me a joke
🤖 Bot: Why did the AI go to school? To improve its learning model! 😄

👤 You: What time is it?
🤖 Bot: It's currently 02:45 PM

👤 You: [Click 🎤 Voice Input and speak]
🤖 Bot: [Listens and responds]
```

---

## Configuration

### Config File: `config/config.py`

```python
# Enable/disable features
ENABLE_VOICE_INPUT = True
ENABLE_VOICE_OUTPUT = True
ENABLE_CHAT_HISTORY = True
ENABLE_SENTIMENT_ANALYSIS = True
OFFLINE_MODE = True  # No API key needed

# Voice settings
VOICE_RATE = 150  # Words per minute
VOICE_TIMEOUT = 10  # Seconds to listen
VOICE_LANGUAGE = "en-US"
```

### Avatar Configuration: `config/avatars.py`

```python
AVATARS = {
    "😊 Friendly": {...},
    "🤖 Robot": {...},
    "👨‍💼 Professional": {...},
    # ... more avatars
}
```

### Knowledge Base: `config/knowledge_base.py`

Add custom responses:

```python
KNOWLEDGE_BASE = {
    "your question": "Your response",
    "python": "Python is awesome!",
    # ... more entries
}
```

---

## Architecture

```
ai-voice-chatbot/
├── app.py                  # Main Streamlit app
├── requirements.txt        # Dependencies
├── config/                 # Configuration files
│   ├── config.py          # Main config
│   ├── avatars.py         # Avatar definitions
│   ├── knowledge_base.py   # Q&A database
│   └── __init__.py
├── utils/                  # Utility modules
│   ├── speech.py          # Voice I/O
│   ├── chat.py            # Chat logic
│   ├── logger.py          # Logging
│   ├── data_handler.py    # Data management
│   └── __init__.py
├── src/                    # Source modules
│   └── __init__.py
├── data/                   # Data storage
│   └── chat_history.json   # Saved conversations
├── logs/                   # Log files
│   └── chatbot_*.log       # Daily logs
├── .streamlit/             # Streamlit config
│   ├── config.toml         # Streamlit settings
│   └── secrets.toml        # API keys (if needed)
├── run.bat                 # Windows launcher
├── run.ps1                 # PowerShell launcher
└── test_app.py             # Unit tests
```

---

## API Reference

### Speech Module (`utils/speech.py`)

```python
# Text to speech
speak(text, rate=1.0)  # rate: 0.5-2.0

# Speech recognition
text = recognize_speech()  # Returns text or None

# Check availability
available = is_speech_available()  # Returns True/False
```

### Chat Module (`utils/chat.py`)

```python
# Get AI response
response = get_ai_response(user_message)

# Check message type
is_greeting(text)    # Returns True/False
is_farewell(text)    # Returns True/False

# Extract keywords
keywords = extract_keywords(text)

# Generate sentiment response
response = generate_sentiment_response(text)
```

### Data Module (`utils/data_handler.py`)

```python
# Save chat
save_chat_history(messages)

# Load chat
messages = load_chat_history()

# Clear chat
clear_chat_history()

# Export chat
filepath = export_chat_history(messages, filename)

# Get stats
stats = get_chat_statistics(messages)
```

### Logging Module (`utils/logger.py`)

```python
from utils.logger import log_info, log_error, log_warning, log_debug

log_info("Message")
log_error("Error")
log_warning("Warning")
log_debug("Debug info")
```

---

## Troubleshooting

### ❌ Microphone Not Working

**Problem**: "Microphone not found" warning

**Solutions**:
1. Check Windows Settings → Privacy & Security → Microphone → Enabled
2. Check if microphone is connected
3. Restart the app
4. Try a different microphone

### ❌ App Won't Start

**Problem**: "ModuleNotFoundError" or import errors

**Solutions**:
1. Make sure you're in project folder
2. Re-run: `pip install -r requirements.txt`
3. Check Python version: `python --version` (should be 3.8+)
4. Delete `__pycache__` folders and try again

### ❌ No Voice Output

**Problem**: Bot doesn't speak responses

**Solutions**:
1. Check Windows volume settings (system tray)
2. Unmute speakers
3. Enable "🔊 Auto-speak responses" in sidebar
4. Check speaker connection

### ❌ Voice Not Recognized

**Problem**: Microphone hears but doesn't understand

**Solutions**:
1. Speak clearly and slowly
2. Reduce background noise
3. Use a better microphone
4. Speak English (default language)

### ❌ Chat History Lost

**Problem**: Chat history not saving

**Solutions**:
1. Check `data/` folder exists
2. Check write permissions for `data/` folder
3. Ensure `ENABLE_CHAT_HISTORY = True` in config
4. Check disk space availability

---

## Contributing

### How to Add Custom Responses

1. Edit `config/knowledge_base.py`
2. Add to `KNOWLEDGE_BASE` dictionary:

```python
KNOWLEDGE_BASE = {
    "your question": "Your response",
    # Add here:
    "what is ai": "AI is amazing!",
}
```

3. Save and restart the app

### How to Add New Avatar

1. Edit `config/avatars.py`
2. Add to `AVATARS` dictionary:

```python
AVATARS = {
    "🎪 Entertainer": {
        "emoji": "🎪",
        "color": "#FF69B4",
        "description": "Fun and entertaining",
        "greeting": "Let's have fun!",
    },
}
```

3. Save and restart

---

## FAQ

**Q: Is this app completely free?**
A: Yes! 100% free. No subscriptions, no API keys required.

**Q: Does it need internet?**
A: No! Everything works offline. No data sent anywhere.

**Q: Can I use ChatGPT instead?**
A: Yes! Get free $5 API credit at openai.com/signup and add your key to `.streamlit/secrets.toml`

**Q: How do I save my chats?**
A: Chat history auto-saves to `data/chat_history.json`

**Q: Can I run this on my phone?**
A: Not directly. You'd need a way to run Streamlit on mobile.

**Q: Is my data private?**
A: Yes! Everything stays on your computer. Nothing is sent online.

---

## License

MIT License - Feel free to use and modify!

---

## Support

- 📧 Email: support@example.com
- 🐛 Report bugs: GitHub Issues
- 💡 Feature requests: GitHub Discussions
- 📖 Full docs: See README.md

---

**Made with ❤️ for better human-AI interaction**
