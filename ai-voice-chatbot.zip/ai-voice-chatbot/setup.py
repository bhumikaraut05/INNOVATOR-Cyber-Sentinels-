#!/usr/bin/env python
"""
AI Voice Chatbot - Setup script
"""

import os
import sys
import subprocess

def create_directories():
    """Create necessary directories"""
    dirs = ['data', 'logs', 'config', 'utils', 'src']
    for dir_name in dirs:
        os.makedirs(dir_name, exist_ok=True)
    print("✅ Directories created")

def install_requirements():
    """Install required packages"""
    print("📥 Installing dependencies...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
    print("✅ Dependencies installed")

def main():
    """Main setup function"""
    print("🚀 AI Voice Chatbot Setup")
    print("=" * 40)
    
    # Create directories
    create_directories()
    
    # Install requirements
    install_requirements()
    
    print("=" * 40)
    print("✨ Setup complete!")
    print("🎯 Run the app: streamlit run app.py")

if __name__ == "__main__":
    main()
