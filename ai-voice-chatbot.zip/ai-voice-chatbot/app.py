"""
AI Voice Chatbot - Enhanced Version v2.0
A free, offline AI assistant with voice I/O and custom avatar creation
"""

import streamlit as st
import base64
import os
from config import (
    APP_TITLE, APP_ICON, PAGE_LAYOUT, INITIAL_SIDEBAR_STATE,
    ENABLE_VOICE_INPUT, ENABLE_VOICE_OUTPUT, ENABLE_CHAT_HISTORY, DEFAULT_BOT_NAME
)
from config.avatars import get_avatar_list, AVATARS
from utils.speech import speak, recognize_speech, is_speech_available
from utils.chat import get_ai_response, is_greeting, is_farewell
from utils.data_handler import save_chat_history, load_chat_history, clear_chat_history, get_chat_statistics
from utils.pdf_handler import create_services_pdf, create_chat_export_pdf
from utils.avatar_creator import (
    load_custom_avatars, create_custom_avatar, delete_custom_avatar, 
    get_all_avatars, is_custom_avatar
)
from utils.avatar_generator import generate_3d_avatar, get_avatar_image, generate_profile_avatar
from utils.theme_manager import (
    get_all_themes, get_theme_settings, set_current_theme, save_custom_theme,
    load_user_theme, get_theme_css, delete_custom_theme, DEFAULT_THEMES
)
from utils.logger import log_info, log_error

# ============================================================================
# PAGE CONFIGURATION
# ============================================================================

st.set_page_config(
    page_title=APP_TITLE,
    page_icon=APP_ICON,
    layout=PAGE_LAYOUT,
    initial_sidebar_state=INITIAL_SIDEBAR_STATE
)

# ============================================================================
# SESSION STATE INITIALIZATION (MUST BE FIRST)
# ============================================================================

if "messages" not in st.session_state:
    st.session_state.messages = []
    log_info("New session started")

if "voice_enabled" not in st.session_state:
    st.session_state.voice_enabled = is_speech_available()

if "text_input_key" not in st.session_state:
    st.session_state.text_input_key = 0

if "show_avatar_creator" not in st.session_state:
    st.session_state.show_avatar_creator = False

if "show_services_pdf" not in st.session_state:
    st.session_state.show_services_pdf = False

if "current_theme" not in st.session_state:
    st.session_state.current_theme = load_user_theme()

if "avatar_style" not in st.session_state:
    st.session_state.avatar_style = "geometric"

# ============================================================================
# CUSTOM CSS - ENHANCED UI WITH THEME SUPPORT
# ============================================================================

# Get current theme
current_theme = get_theme_settings(st.session_state.current_theme)

# Apply theme CSS
st.markdown("""
    <style>
        #MainMenu {visibility: hidden;}
        [data-testid="stToolbar"] {visibility: hidden;}
        
        :root {
            --primary-color: """ + current_theme['primary_color'] + """;
            --secondary-color: """ + current_theme['secondary_color'] + """;
            --accent-color: """ + current_theme['accent_color'] + """;
            --bg-color: """ + current_theme['bg_color'] + """;
            --text-color: """ + current_theme['text_color'] + """;
            --chat-user-bg: """ + current_theme['chat_user_bg'] + """;
            --chat-bot-bg: """ + current_theme['chat_bot_bg'] + """;
        }
        
        .stApp, [data-testid="stAppViewContainer"] {
            background-color: var(--bg-color) !important;
            color: var(--text-color) !important;
        }

        [data-testid="stSidebar"], [data-testid="stSidebarContent"] {
            background-color: var(--chat-bot-bg) !important;
            color: var(--text-color) !important;
        }

        .stApp p, .stApp h1, .stApp h2, .stApp h3, .stApp h4, .stApp span, .stApp label, .stApp div[data-testid="stMarkdownContainer"] {
            color: var(--text-color) !important;
        }
        
        .header-title {
            font-size: 2.5rem;
            font-weight: bold;
            color: var(--primary-color);
            text-align: center;
            margin-bottom: 1rem;
            animation: fadeIn 0.5s ease-in;
        }
        
        .chat-message-user {
            background-color: var(--chat-user-bg);
            padding: 1rem;
            border-radius: 10px;
            margin: 0.5rem 0;
            border-left: 4px solid var(--primary-color);
        }
        
        .chat-message-bot {
            background-color: var(--chat-bot-bg);
            padding: 1rem;
            border-radius: 10px;
            margin: 0.5rem 0;
            border-left: 4px solid var(--secondary-color);
        }
        
        .stButton>button {
            border-radius: 8px;
            font-weight: 500;
            transition: all 0.3s;
            background-color: var(--primary-color) !important;
        }
        
        .stButton>button:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            background-color: var(--secondary-color) !important;
        }
        
        .support-panel {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            padding: 1.5rem;
            border-radius: 10px;
            color: white;
            text-align: center;
            margin: 1rem 0;
        }
        
        .feature-box {
            background-color: var(--chat-bot-bg);
            padding: 1rem;
            border-radius: 8px;
            margin: 0.5rem 0;
            border: 2px solid var(--primary-color);
        }
        
        .avatar-display {
            text-align: center;
            padding: 1rem;
            border-radius: 10px;
            background-color: var(--chat-bot-bg);
        }
        
        .avatar-display img {
            border-radius: 50%;
            width: 150px;
            height: 150px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
    </style>
""", unsafe_allow_html=True)

# ============================================================================
# SIDEBAR CONFIGURATION - ENHANCED
# ============================================================================

with st.sidebar:
    st.markdown("## Configuration")
    st.markdown("---")
    
    # Tabs for different sections
    tab1, tab2, tab3, tab4 = st.tabs(["Home", "Create Avatar", "Help", "Themes"])
    
    with tab1:
        st.subheader("Bot Configuration")
        
        # Get all avatars (preset + custom) and build display list
        all_avatars = get_all_avatars()
        display_options = []
        avatar_key_map = {}
        for key, data in all_avatars.items():
            label = data.get('display_name', key.title())
            display_options.append(label)
            avatar_key_map[label] = key
        
        if 'selected_avatar' not in st.session_state:
            st.session_state.selected_avatar = list(all_avatars.keys())[0] if all_avatars else None
        
        chosen_label = st.selectbox(
            "Choose Avatar:",
            options=display_options,
            index=display_options.index(all_avatars.get(st.session_state.selected_avatar, {}).get('display_name', st.session_state.selected_avatar or '')) if st.session_state.selected_avatar else 0,
            help="Select your preferred chatbot personality"
        )
        selected_avatar = avatar_key_map.get(chosen_label, st.session_state.selected_avatar)
        st.session_state.selected_avatar = selected_avatar
        
        # Bot name customization
        bot_name = st.text_input(
            "Bot Name:",
            value=DEFAULT_BOT_NAME,
            help="Give your bot a custom name"
        )
        
        st.markdown("---")
        st.subheader("Voice Settings")
        
        # Voice settings
        voice_speed = st.slider(
            "Voice Speed:",
            min_value=0.5,
            max_value=2.0,
            value=1.0,
            step=0.1,
            help="Adjust how fast the bot speaks"
        )
        
        # Auto-speak toggle
        auto_speak = st.checkbox(
            "Auto-speak responses",
            value=True,
            help="Automatically speak bot responses"
        )
        
        # Voice input toggle
        enable_voice = st.checkbox(
            "Enable voice input",
            value=st.session_state.voice_enabled and ENABLE_VOICE_INPUT,
            help="Enable microphone input"
        )
        
        st.markdown("---")
        st.subheader("Chat Management")
        
        # Status display
        col1, col2 = st.columns(2)
        with col1:
            st.metric("Messages", len(st.session_state.messages))
        with col2:
            stats = get_chat_statistics(st.session_state.messages)
            st.metric("User Msgs", stats['user_messages'])
        
        # Microphone availability
        if st.session_state.voice_enabled:
            st.success("Microphone available")
        else:
            st.warning("Microphone not found")
        
        st.markdown("---")
        
        # Data management section
        col_load, col_clear = st.columns(2)
        with col_load:
            if st.button("Load History", use_container_width=True):
                st.session_state.messages = load_chat_history()
                if st.session_state.messages:
                    st.success("Chat history loaded!")
                    st.rerun()
        
        with col_clear:
            if st.button("Clear Chat", use_container_width=True):
                clear_chat_history()
                st.session_state.messages = []
                st.success("Chat cleared!")
                st.rerun()
        
        # Export chat to PDF
        st.markdown("---")
        st.subheader("Export Chat as PDF")
        
        if st.button("Generate PDF Report", use_container_width=True, key="export_pdf_btn"):
            if st.session_state.messages:
                with st.spinner("Creating PDF..."):
                    avatar_emoji = all_avatars.get(selected_avatar, {}).get('emoji', '')
                    pdf_file = create_chat_export_pdf(st.session_state.messages, bot_name, avatar_emoji)
                    if pdf_file:
                        st.success(f"PDF created: {pdf_file}")
                        try:
                            with open(pdf_file, 'rb') as f:
                                st.download_button(
                                    label="Download PDF",
                                    data=f.read(),
                                    file_name=pdf_file,
                                    mime="application/pdf",
                                    use_container_width=True
                                )
                        except:
                            st.info("PDF ready for download")
            else:
                st.warning("No messages to export. Start chatting first!")
        
        # Statistics
        if st.button("Show Statistics", use_container_width=True):
            stats = get_chat_statistics(st.session_state.messages)
            st.markdown("### Chat Statistics")
            for stat, value in stats.items():
                st.write(f"**{stat.replace('_', ' ').title()}:** {value}")
        
        st.markdown("---")
        
        # Display avatar info WITH 3D AVATAR IMAGE
        if selected_avatar in all_avatars:
            avatar_info = all_avatars[selected_avatar]
            is_custom = is_custom_avatar(selected_avatar)
            custom_badge = " (Custom)" if is_custom else ""
            display_name = avatar_info.get('display_name', selected_avatar.title())
            
            st.markdown(f"""
                **Current Bot:** {avatar_info['emoji']} {display_name}{custom_badge}  
                **Personality:** {avatar_info['description']}  
                **Greeting:** {avatar_info['greeting'][:50]}...
            """)
            # Display 3D GLB Avatar
            st.markdown("---")
            st.subheader("3D Avatar")
            
            # Use the avatar's specific GLB URL if they have one, otherwise use the default Ready Player Me avatar
            rpm_model_url = avatar_info.get("glb_url") or "https://models.readyplayer.me/69a002e62de3dcd983bb7fb9.glb"
            
            # HTML to display model-viewer
            model_html = f"""
            <script type="module" src="https://ajax.googleapis.com/ajax/libs/model-viewer/3.4.0/model-viewer.min.js"></script>
            <style>
                .avatar-container {{
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    border-radius: 12px;
                    overflow: hidden;
                }}
                model-viewer {{
                    width: 100%;
                    height: 300px;
                    background-color: transparent;
                }}
            </style>
            <div class="avatar-container">
                <model-viewer 
                    src="{rpm_model_url}" 
                    alt="Ready Player Me Avatar" 
                    auto-rotate 
                    camera-controls 
                    shadow-intensity="1"
                    camera-orbit="0deg 80deg 2.5m">
                </model-viewer>
            </div>
            """
            import streamlit.components.v1 as components
            components.html(model_html, height=320)
    
    with tab2:
        st.subheader("Create Custom Avatar")
        st.markdown("""
            Create your own unique avatar personality for the chatbot.
            Just like Snapchat or WhatsApp avatars!
        """)
        
        st.markdown("---")
        
        with st.form("avatar_creation_form"):
            avatar_name = st.text_input(
                "Avatar Name:",
                placeholder="e.g., Happy Bot, Game Master",
                help="Give your avatar a unique name"
            )
            
            avatar_emoji = st.text_input(
                "Avatar Emoji:",
                value="🤖",
                max_chars=5,
                help="Choose an emoji to represent your avatar"
            )
            
            avatar_color = st.color_picker(
                "Avatar Color:",
                value="#0066CC",
                help="Pick a color for your avatar"
            )
            
            avatar_description = st.text_area(
                "Personality Description:",
                placeholder="Describe this avatar's personality and style...",
                height=80,
                max_chars=200
            )
            
            avatar_greeting = st.text_area(
                "Custom Greeting:",
                placeholder="What should this avatar say when starting a conversation?",
                height=80,
                max_chars=300
            )
            
            avatar_glb_url = st.text_input(
                "3D Avatar GLB URL (Optional):",
                placeholder="e.g. https://models.readyplayer.me/...",
                help="Paste a URL to a custom Ready Player Me .glb model"
            )
            
            if st.form_submit_button("Create Avatar"):
                if all([avatar_name, avatar_emoji, avatar_description, avatar_greeting]):
                    
                    # Validate GLB URL
                    final_glb_url = avatar_glb_url.strip()
                    if final_glb_url and not final_glb_url.startswith("http"):
                        st.warning("⚠️ The 3D Avatar GLB URL must start with 'http'. Ignoring the invalid URL and using the default avatar.")
                        final_glb_url = None
                    else:
                        final_glb_url = final_glb_url if final_glb_url else None
                        
                    result = create_custom_avatar(
                        avatar_name,
                        avatar_emoji,
                        avatar_color,
                        avatar_description,
                        avatar_greeting,
                        glb_url=final_glb_url
                    )
                    if result:
                        st.success(f"Avatar '{avatar_name}' created successfully!")
                        st.balloons()
                        # refresh list
                        st.rerun()
                    else:
                        st.error("Avatar name already exists. Please use a different name.")
                else:
                    st.error("Please fill in all fields (GLB URL is optional)")
        
        st.markdown("---")
        st.subheader("Your Custom Avatars")
        
        custom_avatars = load_custom_avatars()
        if custom_avatars:
            for avatar_key, avatar_data in custom_avatars.items():
                display_name = avatar_data.get('display_name', avatar_key.title())
                col1, col2, col3 = st.columns([3,3,1])
                with col1:
                    st.markdown(f"""
                        **{avatar_data['emoji']} {display_name}**  
                        {avatar_data['description']}
                    """)
                with col2:
                    # show generated avatar image if exists
                    if avatar_data.get('glb_url'):
                        list_model_html = f"""
                        <script type="module" src="https://ajax.googleapis.com/ajax/libs/model-viewer/3.4.0/model-viewer.min.js"></script>
                        <model-viewer 
                            src="{avatar_data['glb_url']}" 
                            auto-rotate 
                            camera-controls 
                            style="width: 100%; height: 100px; background-color: transparent;">
                        </model-viewer>
                        """
                        components.html(list_model_html, height=120)
                    else:
                        avatar_img_path = get_avatar_image(display_name, style=st.session_state.avatar_style)
                        if avatar_img_path and os.path.exists(avatar_img_path):
                            st.image(avatar_img_path, width=80)
                with col3:
                    if st.button("Delete", key=f"del_{avatar_key}"):
                        if delete_custom_avatar(avatar_key):
                            st.success(f"Avatar '{display_name}' deleted!")
                            st.rerun()
        else:
            st.info("No custom avatars yet. Create one above!")
    
    with tab4:
        st.subheader("Theme Customization")
        st.markdown("Personalize the chatbot appearance with custom themes!")
        
        st.markdown("---")
        st.subheader("Select Theme")
        
        all_themes = get_all_themes()
        theme_names = list(all_themes.keys())
        
        current_theme_idx = 0
        try:
            current_theme_idx = theme_names.index(st.session_state.current_theme)
        except:
            current_theme_idx = 0
        
        selected_theme = st.selectbox(
            "Available Themes:",
            options=theme_names,
            index=current_theme_idx,
            format_func=lambda x: all_themes[x].get('name', x.title())
        )
        
        if selected_theme != st.session_state.current_theme:
            st.session_state.current_theme = selected_theme
            set_current_theme(selected_theme)
            st.success(f"Theme changed to {all_themes[selected_theme].get('name')}!")
            st.rerun()
        
        st.markdown("---")
        st.subheader("Create Custom Theme")
        
        with st.form("theme_creation_form"):
            theme_name = st.text_input(
                "Theme Name:",
                placeholder="e.g., My Blue Theme",
                help="Give your theme a unique name"
            )
            
            col1, col2 = st.columns(2)
            with col1:
                primary_color = st.color_picker(
                    "Primary Color:",
                    value="#0066CC",
                    help="Main color for buttons and headers"
                )
            with col2:
                secondary_color = st.color_picker(
                    "Secondary Color:",
                    value="#667eea",
                    help="Secondary accent color"
                )
            
            col1, col2 = st.columns(2)
            with col1:
                bg_color = st.color_picker(
                    "Background Color:",
                    value="#FFFFFF"
                )
            with col2:
                text_color = st.color_picker(
                    "Text Color:",
                    value="#333333"
                )
            
            col1, col2 = st.columns(2)
            with col1:
                chat_user_bg = st.color_picker(
                    "User Chat BG:",
                    value="#E3F2FD"
                )
            with col2:
                chat_bot_bg = st.color_picker(
                    "Bot Chat BG:",
                    value="#F5F5F5"
                )
            
            if st.form_submit_button("Create Theme"):
                if theme_name:
                    theme_data = {
                        "name": theme_name,
                        "primary_color": primary_color,
                        "secondary_color": secondary_color,
                        "accent_color": primary_color,
                        "bg_color": bg_color,
                        "text_color": text_color,
                        "chat_user_bg": chat_user_bg,
                        "chat_bot_bg": chat_bot_bg,
                        "is_dark": False
                    }
                    
                    if save_custom_theme(theme_name.lower(), theme_data):
                        st.session_state.current_theme = theme_name.lower()
                        set_current_theme(theme_name.lower())
                        st.success(f"Theme '{theme_name}' created and applied!")
                        st.balloons()
                        st.rerun()
                    else:
                        st.error("Failed to create theme")
                else:
                    st.error("Please enter a theme name")
        
        st.markdown("---")
        st.subheader("Theme Preview")
        
        current_settings = get_theme_settings(st.session_state.current_theme)
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.markdown(f"**Primary:** <div style='background-color: {current_settings['primary_color']}; height: 30px; border-radius: 5px;'></div>", unsafe_allow_html=True)
        with col2:
            st.markdown(f"**Secondary:** <div style='background-color: {current_settings['secondary_color']}; height: 30px; border-radius: 5px;'></div>", unsafe_allow_html=True)
        with col3:
            st.markdown(f"**Accent:** <div style='background-color: {current_settings['accent_color']}; height: 30px; border-radius: 5px;'></div>", unsafe_allow_html=True)
    
    with tab3:
        st.subheader("Getting Started")
        st.markdown("""
            **How to use this chatbot:**
            
            1. **Select an Avatar** - Choose from 6 preset avatars or create your own
            2. **Type or Speak** - Use text input or click the microphone button
            3. **Customize Voice** - Adjust speech speed and enable/disable audio
            4. **Save Chats** - Your conversations are automatically saved
            5. **Export Chats** - Download your conversations as PDF
            
            **Quick Commands:**
            - "Hello" to start
            - "Tell me a joke" for fun
            - "What time is it?" for current time
            - "Goodbye" to end
        """)
        
        st.markdown("---")
        st.subheader("Features")
        features = [
            "Voice Input & Output",
            "Custom Avatars",
            "Chat History",
            "PDF Export",
            "Offline Mode",
            "No API Keys"
        ]
        for feature in features:
            st.markdown(f"✅ {feature}")
    
    st.markdown("---")
    st.markdown("**© 2025 AI Voice Chatbot v2.0**  \nFree & Offline | Made with Love")

# ============================================================================
# MAIN HEADER - ENHANCED
# ============================================================================

all_avatars = get_all_avatars()
if selected_avatar in all_avatars:
    avatar_emoji = all_avatars[selected_avatar]["emoji"]
else:
    avatar_emoji = "🤖"

col1, col2, col3 = st.columns([1, 3, 1])
with col1:
    st.empty()
with col2:
    st.markdown(f"<div class='header-title'>{avatar_emoji} {bot_name}</div>", unsafe_allow_html=True)
    st.markdown("<h3 style='text-align: center;'>Voice Chat Assistant</h3>", unsafe_allow_html=True)
    st.caption("✨ Free AI Assistant - No API Key Required!")
with col3:
    if st.button("Support", help="View services and features"):
        st.session_state.show_services_pdf = not st.session_state.show_services_pdf

# Support Panel
if st.session_state.show_services_pdf:
    st.markdown("<div class='support-panel'>", unsafe_allow_html=True)
    st.markdown("### Services & Features")
    
    col1, col2 = st.columns(2)
    with col1:
        if st.button("Download Services PDF"):
            pdf_file = create_services_pdf()
            if pdf_file:
                st.success("PDF generated successfully!")
                try:
                    with open(pdf_file, 'rb') as f:
                        st.download_button(
                            label="Download PDF",
                            data=f.read(),
                            file_name=pdf_file,
                            mime="application/pdf"
                        )
                except:
                    st.info("Services PDF ready: chatbot_services.pdf")
    
    with col2:
        st.markdown("""
            **Available Services:**
            - Voice I/O capabilities
            - 50+ Q&A Knowledge base
            - Sentiment analysis
            - Chat history & export
            - Custom avatar creation
        """)
    st.markdown("</div>", unsafe_allow_html=True)

st.markdown("---")

# ============================================================================
# CHAT DISPLAY AREA - ENHANCED
# ============================================================================

st.subheader("Conversation")

# Display chat history
if st.session_state.messages:
    for idx, message in enumerate(st.session_state.messages):
        if message["role"] == "user":
            st.markdown(f"""
                <div class='chat-message-user'>
                    <b>You:</b> {message['content']}
                </div>
            """, unsafe_allow_html=True)
        else:
            st.markdown(f"""
                <div class='chat-message-bot'>
                    <b>{avatar_emoji} {bot_name}:</b> {message['content']}
                </div>
            """, unsafe_allow_html=True)
else:
    greeting = all_avatars[selected_avatar]['greeting'] if selected_avatar in all_avatars else "Hello! How can I help you?"
    st.info(f"Hello! I'm {bot_name}. {greeting}")

st.markdown("---")

# ============================================================================
# INPUT AREA - ENHANCED WITH CLEAR FUNCTIONALITY
# ============================================================================

st.subheader("Send Message")

col1, col2, col3, col4 = st.columns([3, 1, 1, 1])

with col1:
    user_input = st.text_input(
        "Type your message:",
        placeholder="Ask me anything...",
        label_visibility="collapsed",
        key=f"text_input_{st.session_state.text_input_key}"
    )

with col2:
    if enable_voice and st.session_state.voice_enabled:
        if st.button("Speak", help="Click to speak (10 seconds)", use_container_width=True):
            with st.spinner("Listening..."):
                recognized_text = recognize_speech()
                if recognized_text:
                    user_input = recognized_text
                    st.rerun()

with col3:
    if st.button("Send", use_container_width=True):
        if user_input.strip():
            # Add user message
            st.session_state.messages.append({"role": "user", "content": user_input})
            log_info(f"User: {user_input}")
            
            # Clear text input by incrementing the key
            st.session_state.text_input_key += 1
            
            # Get AI response
            with st.spinner(f"{bot_name} is thinking..."):
                ai_response = get_ai_response(user_input)
            
            # Add AI response
            st.session_state.messages.append({"role": "assistant", "content": ai_response})
            log_info(f"{bot_name}: {ai_response}")
            
            # Speak response
            if auto_speak and ENABLE_VOICE_OUTPUT:
                with st.spinner("Speaking..."):
                    speak(ai_response, voice_speed)
            
            # Save chat history
            if ENABLE_CHAT_HISTORY:
                save_chat_history(st.session_state.messages)
            
            st.rerun()

with col4:
    if st.button("Refresh", use_container_width=True):
        st.rerun()

# ============================================================================
# QUICK COMMANDS - ENHANCED
# ============================================================================

st.markdown("---")

st.subheader("Quick Commands")

quick_commands = [
    "Hello!",
    "Tell me a joke",
    "What time is it?",
    "What's today's date?",
    "Help me"
]

cols = st.columns(len(quick_commands))
for idx, command in enumerate(quick_commands):
    if cols[idx].button(command, use_container_width=True):
        # Add command as user message
        st.session_state.messages.append({"role": "user", "content": command})
        
        # Clear text input
        st.session_state.text_input_key += 1
        
        # Get response
        ai_response = get_ai_response(command)
        st.session_state.messages.append({"role": "assistant", "content": ai_response})
        
        # Speak if enabled
        if auto_speak and ENABLE_VOICE_OUTPUT:
            speak(ai_response, voice_speed)
        
        # Save history
        if ENABLE_CHAT_HISTORY:
            save_chat_history(st.session_state.messages)
        
        st.rerun()

# ============================================================================
# FEATURES SHOWCASE
# ============================================================================

st.markdown("---")

st.subheader("Key Features")

col1, col2, col3 = st.columns(3)

with col1:
    st.markdown("""
        <div class='feature-box'>
            <h4>Voice I/O</h4>
            Speak to the bot and listen to responses with natural voice output.
        </div>
    """, unsafe_allow_html=True)

with col2:
    st.markdown("""
        <div class='feature-box'>
            <h4>Smart Chat</h4>
            Intelligent responses powered by knowledge base and sentiment analysis.
        </div>
    """, unsafe_allow_html=True)

with col3:
    st.markdown("""
        <div class='feature-box'>
            <h4>No API Key</h4>
            Completely free and offline - no subscription or API keys needed!
        </div>
    """, unsafe_allow_html=True)

# ============================================================================
# FOOTER
# ============================================================================

st.markdown("---")

col1, col2, col3 = st.columns([1, 1, 1])

with col1:
    st.markdown("**Features**")
    st.caption("Voice I/O  \nCustom Avatars  \nChat Export")

with col2:
    st.markdown("**Data**")
    st.caption("Saved Locally  \nNo Cloud  \nComplete Privacy")

with col3:
    st.markdown("**Info**")
    st.caption("Version: 2.0  \nFree & Open  \nOffline Mode")

st.markdown("""
    <div style='text-align: center; margin-top: 2rem; padding: 1rem; background-color: #F5F5F5; border-radius: 8px;'>
        <p><b>AI Voice Chatbot v2.0</b></p>
        <p style='font-size: 11px; color: #666;'>Free & Offline AI Assistant with Voice & Custom Avatars</p>
        <p style='font-size: 10px; color: #999;'>Made with love | Complete Privacy | No Tracking</p>
    </div>
""", unsafe_allow_html=True)
