# 🤖 AI Voice Chatbot - Complete Edition

### ✨ Features
- 🎤 **Voice Input & Output** - Talk naturally with your AI
- 💬 **Smart Chat** - Intelligent, context-aware responses
- 🎭 **6 Avatars** - Choose your bot's personality
- 🌟 **NO API KEY REQUIRED** - Completely free & offline
- 📝 **Chat History** - Save and load conversations
- ⚙️ **Customizable** - Bot name, voice speed, and more
- 📊 **Statistics** - Track your conversations
- 🚀 **Easy Setup** - Works out of the box

---

## 🚀 Quick Start (Choose One)

### ⭐ Windows - Easiest (Recommended)

**Step 1:** Double-click `run.bat`

That's it! The app opens automatically.

### 🐧 macOS / Linux

```bash
source venv/bin/activate
streamlit run app.py
```

### 👨‍💻 Manual Setup (All Platforms)

```bash
# 1. Create virtual environment
python -m venv venv

# 2. Activate it
# Windows:
venv\Scripts\activate.bat
# macOS/Linux:
source venv/bin/activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Run app
streamlit run app.py
```

---

## 📋 Requirements

- ✅ Python 3.8 or higher
- ✅ Microphone (for voice input, optional)
- ✅ ~200MB disk space
- ❌ NO API KEY needed!
- ❌ NO internet connection needed!

---

## 🎮 How to Use

### Basic Usage

1. **Launch App** → Double-click `run.bat` (Windows) or run command above
2. **Choose Avatar** → Select from 6 personalities in sidebar
3. **Name Your Bot** → Give your AI a custom name
4. **Adjust Settings** → Voice speed, auto-speak, etc.
5. **Start Chatting**:
   - Type a message → Click "Send ✈️"
   - OR click "🎤" → Speak naturally → Bot responds

### Example Conversations

```
👤 You: Hello!
🤖 Bot: Hello! How can I help you today?

👤 You: Tell me a joke
🤖 Bot: Why did the AI go to school? To improve its learning model! 😄

👤 You: What's the time?
🤖 Bot: It's currently 02:45 PM

👤 You: [Click 🎤 and speak]
🤖 Bot: [Listens and responds naturally]
```

---

## 🛠️ Configuration

### Avatars Available

| Avatar | Emoji | Personality |
|--------|-------|-------------|
| Friendly | 😊 | Warm and approachable |
| Robot | 🤖 | Logical and precise |
| Professional | 👨‍💼 | Business-like and formal |
| Tech Expert | 👩‍💻 | Tech-savvy and helpful |
| Wizard | 🧙‍♂️ | Mystical and wise |
| Creative | 🎨 | Artistic and fun |

### Customization

Edit files in `config/` folder:

- **`config.py`** - Main settings
- **`avatars.py`** - Avatar personalities
- **`knowledge_base.py`** - Q&A responses

---

## 📂 Project Structure

```
ai-voice-chatbot/
├── app.py                    # Main application
├── requirements.txt          # Dependencies
├── config/                   # Configuration
│   ├── config.py
│   ├── avatars.py
│   ├── knowledge_base.py
│   └── __init__.py
├── utils/                    # Core utilities
│   ├── speech.py            # Voice I/O
│   ├── chat.py              # Chat logic
│   ├── logger.py            # Logging
│   ├── data_handler.py      # Data management
│   └── __init__.py
├── data/                    # Conversation data
│   └── chat_history.json
├── logs/                    # Application logs
│   └── chatbot_YYYYMMDD.log
├── .streamlit/              # Streamlit config
├── run.bat                  # Windows launcher
├── run.ps1                  # PowerShell launcher
├── setup.bat                # Windows setup
├── setup.sh                 # Linux/Mac setup
├── test_app.py              # Unit tests
├── README.md                # This file
└── DOCUMENTATION.md         # Full documentation
```

---

## 🔊 Voice Features

### Voice Input

1. Click **🎤 Voice Input** button
2. Wait for "🎤 Listening..." message
3. Speak clearly (up to 10 seconds)
4. Bot recognizes your speech and responds

### Voice Output

1. Enable **"🔊 Auto-speak responses"** in sidebar
2. Bot will speak all responses automatically
3. Adjust **"Voice Speed"** slider (0.5x - 2.0x)

### Troubleshooting Voice

- **Microphone not found?**
  - Check Windows Settings → Privacy → Microphone
  - Ensure microphone is connected
  - Restart the app

- **No voice output?**
  - Check system volume
  - Enable auto-speak option
  - Check speaker connection

---

## 💾 Data Management

### Auto-Save

- Chat history saves automatically
- Stored in `data/chat_history.json`
- Loads on app restart

### Manual Management (Sidebar)

- **📥 Load History** - Load previous chats
- **🗑️ Clear Chat** - Delete current conversation
- **📊 Show Statistics** - View chat metrics

---

## 🆚 FREE vs ChatGPT Version

| Feature | FREE Version | ChatGPT Version |
|---------|-------------|-----------------|
| Voice I/O | ✅ | ✅ |
| Offline | ✅ | ❌ |
| API Key | ❌ | ✅ |
| Cost | Free | $0.01-0.10 per 1000 tokens |
| AI Power | Good | Excellent |
| Internet | Not needed | Required |
| Privacy | Local only | Sent to OpenAI |

---

## 🎯 Upgrade to ChatGPT

Want more powerful AI? It's optional!

1. Go to [openai.com/signup](https://platform.openai.com/signup)
2. Create account → Get **Free $5 Credit**
3. Copy your API key
4. Edit `.streamlit/secrets.toml`:
   ```
   OPENAI_API_KEY = "sk-your-key-here"
   ```
5. Restart app → ChatGPT power unlocked!

---

## 🧪 Testing

Run tests:

```bash
python test_app.py
```

---

## ❓ FAQ

**Q: Is this really free?**
A: Yes! 100% free. No hidden costs or limitations.

**Q: Where does my data go?**
A: Nowhere! Everything stays on your computer. We don't collect any data.

**Q: Can I use this offline?**
A: Yes! All features work without internet (except ChatGPT upgrade).

**Q: How do I reset everything?**
A: Delete `data/chat_history.json` and `logs/` folder.

**Q: Can I add my own responses?**
A: Yes! Edit `config/knowledge_base.py` and add your Q&A pairs.

**Q: Does it work on tablets/phones?**
A: Not directly, but you can use remote access (SSH, VPN, etc.).

**Q: How good is the AI?**
A: Good for general chat and simple tasks. For advanced tasks, upgrade to ChatGPT.

---

## 🐛 Troubleshooting

### App won't start?
```bash
# Delete cache and try again
rm -rf __pycache__ .streamlit/cache
python -m pip install -r requirements.txt
streamlit run app.py
```

### Import errors?
```bash
# Reinstall all packages
pip install --upgrade -r requirements.txt
```

### Voice not working?
- Check microphone in Windows settings
- Ensure microphone is connected and enabled
- Test microphone with Windows Sound Settings
- Restart the app

### Slow responses?
- This uses local AI, not API
- First response may be slow
- Subsequent responses are faster

---

## 📚 Documentation

- **[Full Documentation](./DOCUMENTATION.md)** - Complete API reference
- **[Configuration Guide](./config/config.py)** - Detailed settings
- **[Knowledge Base](./config/knowledge_base.py)** - Available Q&A

---

## 🤝 Contributing

Want to improve the bot? Easy!

### Add Custom Responses

1. Edit `config/knowledge_base.py`
2. Add to `KNOWLEDGE_BASE` dictionary:
   ```python
   "your question": "your response"
   ```
3. Restart app

### Add New Avatar

1. Edit `config/avatars.py`
2. Add to `AVATARS` dictionary
3. Restart app

### Report Issues

Found a bug? File an issue on GitHub!

---

## 📄 License

MIT License - Use freely for any purpose!

---

## 💬 Get in Touch

- 📧 Email: support@example.com
- 🐛 Issues: GitHub Issues
- 💡 Ideas: GitHub Discussions
- ⭐ Like it? Star on GitHub!

---

## 🎉 What's New in v2.0

✨ **Major Updates:**
- ✅ Modular architecture (config, utils, src)
- ✅ Advanced logging system
- ✅ Better error handling
- ✅ Chat statistics
- ✅ Data management features
- ✅ Improved UI/UX
- ✅ Full documentation
- ✅ Unit tests

---

**Made with ❤️ for better human-AI interaction**

**Version: 2.0 | Free & Offline | No API Key Required**

