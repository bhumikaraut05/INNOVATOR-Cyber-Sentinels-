"""
Chat utilities for AI Voice Chatbot
"""

import random
from textblob import TextBlob
from config.knowledge_base import get_response
from utils.logger import log_info, log_error

import os
from google import genai
from google.genai import types

def get_ai_response(user_message):
    """
    Get AI response based on user input, using Gemini if available.
    
    Args:
        user_message (str): User's message
        
    Returns:
        str: AI response
    """
    try:
        # Check if Gemini API key exists
        api_key = os.environ.get("GEMINI_API_KEY")
        if api_key:
            client = genai.Client(api_key=api_key)
            
            system_instruction = """You are an advanced multilingual AI assistant.

Your abilities:
1. Automatically detect the language of the user input.
2. Understand and respond fluently in: English, Hindi, Marathi, Spanish, French, German, Chinese, Japanese, Arabic, and any other major world language.
3. If the user mixes languages (Hinglish, etc.), respond naturally in the same style.
4. If the user asks for translation, provide both a direct translation and a simplified meaning (if needed).
5. Maintain a friendly, human-like tone.
6. If unclear, politely ask for clarification.
7. Keep responses clear and structured.

Important:
- Always auto-detect language.
- Never say you cannot understand unless the input is complete gibberish.
- Adapt your tone based on the user's mood (formal/informal)."""

            response = client.models.generate_content(
                model='gemini-2.5-flash',
                contents=user_message,
                config=types.GenerateContentConfig(
                    system_instruction=system_instruction,
                    temperature=0.7,
                ),
            )
            
            log_info("Generated response using Gemini API")
            return response.text
            
        else:
            # Fallback to local logic if no API key
            kb_response = get_response(user_message)
            if kb_response:
                log_info(f"Knowledge base response: {kb_response[:50]}...")
                return kb_response
            
            response = generate_sentiment_response(user_message)
            log_info(f"Generated sentiment fallback response: {response[:50]}...")
            return response
            
    except Exception as e:
        log_error(f"Error generating response: {e}")
        return "I encountered an error connecting to my brain. Could you please check my API keys?"

def generate_sentiment_response(user_message):
    """
    Generate response based on sentiment analysis
    
    Args:
        user_message (str): User's message
        
    Returns:
        str: Generated response
    """
    try:
        # Sentiment analysis
        blob = TextBlob(user_message)
        polarity = blob.sentiment.polarity
        
        # Positive sentiment
        if polarity > 0.5:
            responses = [
                "That sounds wonderful! 😊",
                "That's great to hear!",
                "Amazing! Tell me more!",
                "I love your positive energy!",
                "That's fantastic!",
            ]
        # Negative sentiment
        elif polarity < -0.5:
            responses = [
                "I'm sorry to hear that. 😔",
                "That sounds tough. Stay strong!",
                "Hope things get better soon.",
                "Don't worry, things will improve!",
                "I understand how you feel.",
            ]
        # Neutral sentiment
        else:
            responses = [
                "That's interesting! Tell me more.",
                "I see what you mean.",
                "Got it! Any other questions?",
                "That makes sense!",
                "Interesting perspective!",
                "Tell me more about that.",
                "I understand.",
            ]
        
        return random.choice(responses)
        
    except Exception as e:
        log_error(f"Sentiment analysis error: {e}")
        return "That's interesting! Tell me more."

def extract_keywords(text):
    """
    Extract keywords from text
    
    Args:
        text (str): Input text
        
    Returns:
        list: List of keywords
    """
    blob = TextBlob(text)
    nouns = [word for word, tag in blob.tags if tag == 'NN']
    return nouns

def is_greeting(text):
    """Check if text is a greeting"""
    greetings = ["hello", "hi", "hey", "howdy", "greetings"]
    return any(g in text.lower() for g in greetings)

def is_farewell(text):
    """Check if text is a farewell"""
    farewells = ["goodbye", "bye", "see you", "farewell", "take care"]
    return any(f in text.lower() for f in farewells)
