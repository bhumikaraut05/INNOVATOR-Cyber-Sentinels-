"""
PDF generation module for creating service documents and chat exports
"""

from reportlab.lib.pagesizes import letter, A4
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak, Table, TableStyle, Image
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_JUSTIFY
from datetime import datetime
import os
from utils.logger import log_info, log_error

def create_services_pdf():
    """
    Create a PDF document with all chatbot services
    
    Returns:
        str: Path to the generated PDF file
    """
    try:
        # Create PDF file
        pdf_path = "chatbot_services.pdf"
        doc = SimpleDocTemplate(pdf_path, pagesize=letter,
                              topMargin=0.5*inch, bottomMargin=0.5*inch)
        
        styles = getSampleStyleSheet()
        story = []
        
        # Custom styles
        title_style = ParagraphStyle(
            'CustomTitle',
            parent=styles['Heading1'],
            fontSize=24,
            textColor=colors.HexColor('#0066CC'),
            spaceAfter=30,
            alignment=TA_CENTER,
            fontName='Helvetica-Bold'
        )
        
        heading_style = ParagraphStyle(
            'CustomHeading',
            parent=styles['Heading2'],
            fontSize=14,
            textColor=colors.HexColor('#003366'),
            spaceAfter=12,
            spaceBefore=12,
            fontName='Helvetica-Bold'
        )
        
        body_style = ParagraphStyle(
            'CustomBody',
            parent=styles['BodyText'],
            fontSize=11,
            alignment=TA_JUSTIFY,
            spaceAfter=10
        )
        
        # Title
        story.append(Paragraph("AI Voice Chatbot - Services & Features", title_style))
        story.append(Spacer(1, 0.3*inch))
        
        # Introduction
        intro_text = """
        Welcome to the AI Voice Chatbot, your intelligent free assistant providing 24/7 support 
        with advanced voice capabilities, no API keys required, and complete offline functionality.
        """
        story.append(Paragraph(intro_text, body_style))
        story.append(Spacer(1, 0.2*inch))
        
        # Core Features Section
        story.append(Paragraph("1. Core Features", heading_style))
        features_data = [
            ["Feature", "Description"],
            ["Voice Input", "Speak directly to the chatbot using your microphone"],
            ["Voice Output", "Listen to responses in natural human voice"],
            ["Offline Mode", "Works completely offline without internet connection"],
            ["No API Keys", "No subscription or API keys required"],
            ["Custom Avatars", "Create and customize unique bot personalities"],
            ["Chat History", "Automatic saving and loading of conversations"]
        ]
        
        features_table = Table(features_data, colWidths=[1.5*inch, 4*inch])
        features_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#0066CC')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 11),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('FONTSIZE', (0, 1), (-1, -1), 10),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#F0F0F0')])
        ]))
        story.append(features_table)
        story.append(Spacer(1, 0.3*inch))
        
        # Available Commands
        story.append(Paragraph("2. Available Commands", heading_style))
        commands_data = [
            ["Command", "Purpose"],
            ["Hello/Hi", "Start a conversation with the bot"],
            ["Tell me a joke", "Get a funny joke or witty response"],
            ["What time is it?", "Get current time information"],
            ["What's today's date?", "Know today's date"],
            ["Help me", "Get assistance with chatbot features"],
            ["Goodbye/Bye", "End conversation gracefully"]
        ]
        
        commands_table = Table(commands_data, colWidths=[2*inch, 3.5*inch])
        commands_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#0066CC')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 11),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('FONTSIZE', (0, 1), (-1, -1), 10),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#F0F0F0')])
        ]))
        story.append(commands_table)
        story.append(Spacer(1, 0.3*inch))
        
        # Avatar Personalities
        story.append(Paragraph("3. Avatar Personalities", heading_style))
        avatars_data = [
            ["Avatar", "Personality", "Best For"],
            ["Friendly", "Warm and approachable", "Casual conversations"],
            ["Robot", "Technical and precise", "Technical questions"],
            ["Professional", "Formal and respectful", "Business inquiries"],
            ["Tech", "Modern and trendy", "Tech discussions"],
            ["Wizard", "Mystical and wise", "Deep conversations"],
            ["Creative", "Artistic and imaginative", "Creative brainstorming"]
        ]
        
        avatars_table = Table(avatars_data, colWidths=[1.3*inch, 1.8*inch, 2.4*inch])
        avatars_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#0066CC')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('FONTSIZE', (0, 1), (-1, -1), 9),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#F0F0F0')])
        ]))
        story.append(avatars_table)
        story.append(Spacer(1, 0.3*inch))
        
        # Settings & Customization
        story.append(Paragraph("4. Settings & Customization", heading_style))
        settings_text = """
        <b>Voice Speed:</b> Adjust the speed of the bot's voice output from 0.5x to 2.0x speed.<br/>
        <b>Bot Name:</b> Customize the name of your chatbot assistant.<br/>
        <b>Avatar Selection:</b> Choose from 6 preset avatars or create your own custom avatar.<br/>
        <b>Voice I/O:</b> Toggle microphone input and speaker output on/off as needed.<br/>
        <b>Auto-speak:</b> Enable/disable automatic voice response feature.
        """
        story.append(Paragraph(settings_text, body_style))
        story.append(Spacer(1, 0.2*inch))
        
        # Support & Features
        story.append(Paragraph("5. Technical Features", heading_style))
        tech_text = """
        <b>Knowledge Base:</b> 50+ pre-trained Q&A pairs covering common questions.<br/>
        <b>Sentiment Analysis:</b> Understands context and generates emotionally appropriate responses.<br/>
        <b>Chat History:</b> Automatic save/load functionality with export to PDF capability.<br/>
        <b>Error Handling:</b> Robust error handling with detailed logging for troubleshooting.<br/>
        <b>Local Storage:</b> All data stored locally on your computer - complete privacy.
        """
        story.append(Paragraph(tech_text, body_style))
        story.append(Spacer(1, 0.3*inch))
        
        # Footer
        story.append(Paragraph("_" * 80, body_style))
        footer_text = f"""
        <b>AI Voice Chatbot v2.0</b><br/>
        Free & Offline AI Assistant with Voice Capabilities<br/>
        Generated on: {datetime.now().strftime('%B %d, %Y at %I:%M %p')}<br/>
        No API Keys Required | Complete Privacy | Open Source
        """
        footer_style = ParagraphStyle(
            'Footer',
            parent=styles['Normal'],
            fontSize=9,
            alignment=TA_CENTER,
            textColor=colors.grey
        )
        story.append(Paragraph(footer_text, footer_style))
        
        # Build PDF
        doc.build(story)
        log_info(f"Services PDF created: {pdf_path}")
        return pdf_path
        
    except Exception as e:
        log_error(f"Error creating services PDF: {e}")
        return None

def create_chat_export_pdf(messages, bot_name="AI Assistant", avatar_emoji=""):
    """
    Create PDF export of chat history with enhanced formatting
    
    Args:
        messages (list): List of message dictionaries
        bot_name (str): Name of the bot
        avatar_emoji (str): Avatar emoji for the bot
        
    Returns:
        str: Path to generated PDF file
    """
    try:
        pdf_filename = f"chat_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
        doc = SimpleDocTemplate(pdf_filename, pagesize=letter,
                              topMargin=0.75*inch, bottomMargin=0.75*inch)
        
        styles = getSampleStyleSheet()
        story = []
        
        # Custom styles
        title_style = ParagraphStyle(
            'CustomTitle',
            parent=styles['Heading1'],
            fontSize=20,
            textColor=colors.HexColor('#0066CC'),
            spaceAfter=12,
            alignment=TA_CENTER,
            fontName='Helvetica-Bold'
        )
        
        user_style = ParagraphStyle(
            'UserMessage',
            parent=styles['Normal'],
            fontSize=11,
            textColor=colors.HexColor('#003366'),
            spaceAfter=10,
            leftIndent=30,
            fontName='Helvetica-Bold',
            textTransform='none'
        )
        
        bot_style = ParagraphStyle(
            'BotMessage',
            parent=styles['Normal'],
            fontSize=11,
            textColor=colors.HexColor('#006600'),
            spaceAfter=10,
            leftIndent=30,
            fontName='Helvetica'
        )
        
        # Title with emoji
        title_text = f"{avatar_emoji} Chat with {bot_name}" if avatar_emoji else f"Chat with {bot_name}"
        story.append(Paragraph(title_text, title_style))
        story.append(Spacer(1, 0.15*inch))
        
        # Export info box
        export_date = datetime.now().strftime('%B %d, %Y at %I:%M %p')
        stats_text = f"<b>Exported:</b> {export_date} | <b>Total Messages:</b> {len(messages)} | <b>User Messages:</b> {len([m for m in messages if m['role'] == 'user'])} | <b>Bot Messages:</b> {len([m for m in messages if m['role'] == 'assistant'])}"
        
        export_style = ParagraphStyle(
            'ExportInfo',
            parent=styles['Normal'],
            fontSize=10,
            alignment=TA_CENTER,
            textColor=colors.HexColor('#333333'),
            spaceAfter=12,
            borderPadding=10
        )
        
        story.append(Paragraph(stats_text, export_style))
        story.append(Spacer(1, 0.2*inch))
        
        # Add horizontal line
        story.append(Paragraph("_" * 100, export_style))
        story.append(Spacer(1, 0.15*inch))
        
        # Messages with better formatting
        message_count = 1
        for message in messages:
            msg_number_style = ParagraphStyle(
                'MsgNumber',
                parent=styles['Normal'],
                fontSize=9,
                textColor=colors.grey,
                spaceAfter=2
            )
            
            story.append(Paragraph(f"<i>Message #{message_count}</i>", msg_number_style))
            
            if message["role"] == "user":
                content = message['content'].replace('<', '&lt;').replace('>', '&gt;')
                story.append(Paragraph(f"<b>You:</b> {content}", user_style))
            else:
                content = message['content'].replace('<', '&lt;').replace('>', '&gt;')
                story.append(Paragraph(f"<b>{avatar_emoji} {bot_name}:</b> {content}", bot_style))
            
            message_count += 1
            story.append(Spacer(1, 0.08*inch))
        
        # Footer
        story.append(Spacer(1, 0.3*inch))
        story.append(Paragraph("_" * 100, export_style))
        
        footer_style = ParagraphStyle(
            'Footer',
            parent=styles['Normal'],
            fontSize=9,
            alignment=TA_CENTER,
            textColor=colors.grey,
            spaceAfter=5
        )
        
        footer_text = f"AI Voice Chatbot v2.0 | Free & Offline AI Assistant<br/>This conversation was automatically exported as PDF"
        story.append(Paragraph(footer_text, footer_style))
        
        # Build PDF
        doc.build(story)
        log_info(f"Chat exported to PDF: {pdf_filename}")
        return pdf_filename
        
    except Exception as e:
        log_error(f"Error exporting chat to PDF: {e}")
        return None
