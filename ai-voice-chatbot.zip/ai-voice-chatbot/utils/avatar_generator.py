"""
Advanced 3D-style avatar generator using PIL
Creates unique avatars based on user input
"""

import hashlib
import random
from PIL import Image, ImageDraw, ImageFilter
import os
from config.config import DATA_DIR
from utils.logger import log_info, log_error

AVATARS_DIR = os.path.join(DATA_DIR, "avatars")

def ensure_avatars_dir():
    """Create avatars directory if it doesn't exist"""
    os.makedirs(AVATARS_DIR, exist_ok=True)

def hex_to_rgb(hex_color):
    """Convert hex color to RGB tuple"""
    hex_color = hex_color.lstrip('#')
    return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))

def get_avatar_colors(seed):
    """Generate color palette from seed"""
    random.seed(seed)
    colors = {
        'primary': f"#{random.randint(0, 255):02x}{random.randint(0, 255):02x}{random.randint(0, 255):02x}",
        'secondary': f"#{random.randint(0, 255):02x}{random.randint(0, 255):02x}{random.randint(0, 255):02x}",
        'accent': f"#{random.randint(0, 255):02x}{random.randint(0, 255):02x}{random.randint(0, 255):02x}",
    }
    return colors

def generate_3d_avatar(name, size=200, style="geometric"):
    """
    Generate a unique 3D-style avatar based on name
    
    Args:
        name (str): Avatar name/seed
        size (int): Avatar size in pixels
        style (str): Avatar style (geometric, gradient, minimal)
        
    Returns:
        str: Path to generated avatar image
    """
    try:
        ensure_avatars_dir()
        
        # Create seed from name
        seed = int(hashlib.md5(name.encode()).hexdigest()[:8], 16)
        random.seed(seed)
        
        # Create base image with background
        bg_color = hex_to_rgb(f"#{random.randint(0, 255):02x}{random.randint(0, 255):02x}{random.randint(0, 255):02x}")
        img = Image.new('RGB', (size, size), bg_color)
        draw = ImageDraw.Draw(img, 'RGBA')
        
        if style == "geometric":
            # Draw geometric shapes
            shapes = random.randint(3, 6)
            for i in range(shapes):
                x1 = random.randint(0, size // 2)
                y1 = random.randint(0, size // 2)
                x2 = x1 + random.randint(30, 100)
                y2 = y1 + random.randint(30, 100)
                
                color = hex_to_rgb(f"#{random.randint(0, 255):02x}{random.randint(0, 255):02x}{random.randint(0, 255):02x}")
                shape_type = random.choice(['circle', 'rect', 'polygon'])
                
                if shape_type == 'circle':
                    draw.ellipse([x1, y1, x2, y2], fill=color, outline='white', width=2)
                elif shape_type == 'rect':
                    draw.rectangle([x1, y1, x2, y2], fill=color, outline='white', width=2)
                else:
                    points = [(x1, y1), (x2, y1), ((x1+x2)//2, y2)]
                    draw.polygon(points, fill=color, outline='white')
        
        elif style == "gradient":
            # Create gradient-like effect with circles
            center_x, center_y = size // 2, size // 2
            for i in range(10):
                radius = (size // 2) - (i * size // 20)
                color = hex_to_rgb(f"#{(100 + i*15):02x}{(150 - i*10):02x}{(200 - i*15):02x}")
                draw.ellipse(
                    [center_x - radius, center_y - radius, center_x + radius, center_y + radius],
                    fill=color
                )
        
        elif style == "minimal":
            # Minimal style with one large shape and details
            shapes_count = random.randint(2, 4)
            for i in range(shapes_count):
                size_variant = size // (i + 2)
                x = (size - size_variant) // 2 + random.randint(-20, 20)
                y = (size - size_variant) // 2 + random.randint(-20, 20)
                
                color = hex_to_rgb(f"#{random.randint(50, 200):02x}{random.randint(50, 200):02x}{random.randint(50, 200):02x}")
                draw.ellipse([x, y, x + size_variant, y + size_variant], fill=color, outline='white', width=1)
        
        # Add slight blur for 3D effect
        img = img.filter(ImageFilter.GaussianBlur(radius=0.5))
        
        # Save avatar
        avatar_path = os.path.join(AVATARS_DIR, f"{name.lower()}_{style}_avatar.png")
        img.save(avatar_path)
        log_info(f"3D avatar generated: {name} ({style})")
        
        return avatar_path
        
    except Exception as e:
        log_error(f"Error generating avatar: {e}")
        return None

def generate_profile_avatar(initials, colors=None, size=200):
    """
    Generate avatar with initials (like Google Meet)
    
    Args:
        initials (str): User initials
        colors (dict): Custom colors {bg_color, text_color}
        size (int): Avatar size
        
    Returns:
        str: Path to generated avatar
    """
    try:
        ensure_avatars_dir()
        
        if not colors:
            seed = int(hashlib.md5(initials.encode()).hexdigest()[:8], 16)
            random.seed(seed)
            colors = {
                'bg': hex_to_rgb(f"#{random.randint(0, 255):02x}{random.randint(0, 255):02x}{random.randint(0, 255):02x}"),
                'text': (255, 255, 255)
            }
        else:
            colors['bg'] = hex_to_rgb(colors.get('bg', '#3498db'))
            colors['text'] = hex_to_rgb(colors.get('text', '#ffffff'))
        
        # Create image
        img = Image.new('RGB', (size, size), colors['bg'])
        draw = ImageDraw.Draw(img)
        
        # Draw circle background
        draw.ellipse([0, 0, size, size], fill=colors['bg'])
        
        # Add text (initials)
        try:
            from PIL import ImageFont
            font_size = size // 3
            font = ImageFont.load_default()
        except:
            font = None
        
        text = initials.upper()[:2]
        bbox = draw.textbbox((0, 0), text, font=font)
        text_width = bbox[2] - bbox[0]
        text_height = bbox[3] - bbox[1]
        
        x = (size - text_width) // 2
        y = (size - text_height) // 2
        
        draw.text((x, y), text, fill=colors['text'], font=font)
        
        # Add 3D effect with shadow
        shadow = Image.new('RGBA', (size, size), (0, 0, 0, 0))
        shadow_draw = ImageDraw.Draw(shadow)
        shadow_draw.ellipse([2, 2, size+2, size+2], fill=(0, 0, 0, 80))
        shadow_draw.ellipse([0, 0, size, size], fill=colors['bg'])
        
        img.save(os.path.join(AVATARS_DIR, f"{initials.lower()}_profile.png"))
        
        return os.path.join(AVATARS_DIR, f"{initials.lower()}_profile.png")
        
    except Exception as e:
        log_error(f"Error generating profile avatar: {e}")
        return None

def get_avatar_image(avatar_name, style="geometric"):
    """
    Get or generate avatar image
    
    Args:
        avatar_name (str): Avatar name
        style (str): Avatar style
        
    Returns:
        str: Path to avatar image
    """
    avatar_path = os.path.join(AVATARS_DIR, f"{avatar_name.lower()}_{style}_avatar.png")
    
    if not os.path.exists(avatar_path):
        return generate_3d_avatar(avatar_name, style=style)
    
    return avatar_path
