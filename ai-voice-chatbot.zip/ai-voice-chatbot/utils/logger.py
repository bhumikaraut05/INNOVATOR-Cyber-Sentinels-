"""
Logging utility for AI Voice Chatbot
"""

import logging
import os
import sys
from config import LOG_FILE, LOG_LEVEL, LOG_FORMAT

# Create logger
logger = logging.getLogger("AI_Voice_Chatbot")
logger.setLevel(getattr(logging, LOG_LEVEL))

# Create formatter
formatter = logging.Formatter(LOG_FORMAT)

# File handler with UTF-8 encoding
file_handler = logging.FileHandler(LOG_FILE, encoding='utf-8')
file_handler.setFormatter(formatter)
logger.addHandler(file_handler)

# Console handler with UTF-8 encoding
console_handler = logging.StreamHandler(sys.stdout)
console_handler.setFormatter(formatter)
logger.addHandler(console_handler)

def log_info(message):
    """Log info message"""
    logger.info(message)

def log_error(message):
    """Log error message"""
    logger.error(message)

def log_warning(message):
    """Log warning message"""
    logger.warning(message)

def log_debug(message):
    """Log debug message"""
    logger.debug(message)

# Initial log
logger.info("=" * 50)
logger.info("AI Voice Chatbot Started")
logger.info("=" * 50)
