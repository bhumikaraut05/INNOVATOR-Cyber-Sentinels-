"""
Data handling utilities for chat history
"""

import json
import os
from datetime import datetime
from config import CHAT_HISTORY_FILE
from utils.logger import log_info, log_error

def save_chat_history(messages):
    """
    Save chat history to file
    
    Args:
        messages (list): List of message dictionaries
    """
    try:
        data = {
            "timestamp": datetime.now().isoformat(),
            "messages": messages
        }
        
        os.makedirs(os.path.dirname(CHAT_HISTORY_FILE), exist_ok=True)
        
        with open(CHAT_HISTORY_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        
        log_info(f"Chat history saved ({len(messages)} messages)")
        return True
        
    except Exception as e:
        log_error(f"Error saving chat history: {e}")
        return False

def load_chat_history():
    """
    Load chat history from file
    
    Returns:
        list: List of message dictionaries
    """
    try:
        if not os.path.exists(CHAT_HISTORY_FILE):
            log_info("No chat history found")
            return []
        
        with open(CHAT_HISTORY_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
            messages = data.get('messages', [])
            log_info(f"Chat history loaded ({len(messages)} messages)")
            return messages
        
    except Exception as e:
        log_error(f"Error loading chat history: {e}")
        return []

def clear_chat_history():
    """Clear chat history"""
    try:
        if os.path.exists(CHAT_HISTORY_FILE):
            os.remove(CHAT_HISTORY_FILE)
            log_info("Chat history cleared")
            return True
        return False
    except Exception as e:
        log_error(f"Error clearing chat history: {e}")
        return False

def export_chat_history(messages, filename=None):
    """
    Export chat history to file
    
    Args:
        messages (list): List of message dictionaries
        filename (str): Export filename
    """
    try:
        if filename is None:
            filename = f"chat_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        filepath = os.path.join(os.path.dirname(CHAT_HISTORY_FILE), filename)
        
        data = {
            "timestamp": datetime.now().isoformat(),
            "total_messages": len(messages),
            "messages": messages
        }
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        
        log_info(f"Chat exported to {filename}")
        return filepath
        
    except Exception as e:
        log_error(f"Error exporting chat: {e}")
        return None

def get_chat_statistics(messages):
    """
    Get statistics about chat
    
    Args:
        messages (list): List of message dictionaries
        
    Returns:
        dict: Statistics
    """
    user_msgs = [m for m in messages if m['role'] == 'user']
    ai_msgs = [m for m in messages if m['role'] == 'assistant']
    
    total_chars = sum(len(m['content']) for m in messages)
    
    return {
        'total_messages': len(messages),
        'user_messages': len(user_msgs),
        'ai_messages': len(ai_msgs),
        'total_characters': total_chars,
        'average_message_length': total_chars // len(messages) if messages else 0
    }
