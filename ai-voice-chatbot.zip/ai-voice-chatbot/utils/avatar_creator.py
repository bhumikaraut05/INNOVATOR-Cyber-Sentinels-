"""
Custom avatar creation and management module
"""

import json
import os
from config.config import DATA_DIR
from utils.logger import log_info, log_error

CUSTOM_AVATARS_FILE = os.path.join(DATA_DIR, "custom_avatars.json")

def load_custom_avatars():
    """
    Load custom avatars from file
    
    Returns:
        dict: Dictionary of custom avatars
    """
    try:
        if os.path.exists(CUSTOM_AVATARS_FILE):
            with open(CUSTOM_AVATARS_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {}
    except Exception as e:
        log_error(f"Error loading custom avatars: {e}")
        return {}

def save_custom_avatars(avatars):
    """
    Save custom avatars to file
    
    Args:
        avatars (dict): Dictionary of custom avatars
        
    Returns:
        bool: Success status
    """
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        with open(CUSTOM_AVATARS_FILE, 'w', encoding='utf-8') as f:
            json.dump(avatars, f, indent=2, ensure_ascii=False)
        log_info(f"Custom avatars saved: {len(avatars)} avatars")
        return True
    except Exception as e:
        log_error(f"Error saving custom avatars: {e}")
        return False

def create_custom_avatar(name, emoji, color, description, greeting, glb_url=None):
    """
    Create a new custom avatar
    
    Args:
        name (str): Avatar name
        emoji (str): Avatar emoji representation
        color (str): Avatar color (hex)
        description (str): Avatar personality description
        greeting (str): Custom greeting message
        glb_url (str, optional): URL to a .glb 3D avatar model
        
    Returns:
        dict: Created avatar data
    """
    try:
        display_name = name.strip()
        key = display_name.lower().replace(' ', '_')
        avatar_data = {
            "emoji": emoji,
            "color": color,
            "description": description,
            "greeting": greeting,
            "glb_url": glb_url,
            "is_custom": True,
            "display_name": display_name
        }
        
        # Load existing custom avatars
        custom_avatars = load_custom_avatars()
        
        # Check if avatar name already exists
        if key in custom_avatars:
            log_error(f"Avatar '{display_name}' already exists")
            return None
        
        # Add new avatar
        custom_avatars[key] = avatar_data
        
        # Save to file
        if save_custom_avatars(custom_avatars):
            log_info(f"Custom avatar created: {display_name}")
            return avatar_data
        
        return None
        
    except Exception as e:
        log_error(f"Error creating custom avatar: {e}")
        return None

def get_all_avatars():
    """
    Get all avatars (preset + custom)

    Returns:
        dict: Combined dictionary of all avatars where keys are unique identifiers
              and each value includes a display_name field for UI rendering.
    """
    try:
        from config.avatars import AVATARS

        all_avatars = AVATARS.copy()
        custom_avatars = load_custom_avatars()

        # Ensure custom avatars include a display_name
        for key, data in custom_avatars.items():
            if 'display_name' not in data:
                data['display_name'] = key.title()

        all_avatars.update(custom_avatars)
        return all_avatars

    except Exception as e:
        log_error(f"Error loading all avatars: {e}")
        return {}

def delete_custom_avatar(name):
    """
    Delete a custom avatar
    
    Args:
        name (str): Avatar name
        
    Returns:
        bool: Success status
    """
    try:
        custom_avatars = load_custom_avatars()
        
        if name.lower() in custom_avatars:
            del custom_avatars[name.lower()]
            if save_custom_avatars(custom_avatars):
                log_info(f"Custom avatar deleted: {name}")
                return True
        
        return False
        
    except Exception as e:
        log_error(f"Error deleting custom avatar: {e}")
        return False

def get_custom_avatar_names():
    """
    Get list of custom avatar names
    
    Returns:
        list: List of custom avatar names
    """
    try:
        custom_avatars = load_custom_avatars()
        return list(custom_avatars.keys())
    except Exception as e:
        log_error(f"Error getting custom avatars list: {e}")
        return []

def is_custom_avatar(name):
    """
    Check if an avatar is custom
    
    Args:
        name (str): Avatar name
        
    Returns:
        bool: True if custom, False otherwise
    """
    try:
        custom_avatars = load_custom_avatars()
        return name.lower() in custom_avatars
    except Exception as e:
        log_error(f"Error checking if avatar is custom: {e}")
        return False
