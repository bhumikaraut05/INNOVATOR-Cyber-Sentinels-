"""
Speech recognition and text-to-speech utilities
"""

import streamlit as st
import speech_recognition as sr
import pyttsx3
from utils.logger import log_info, log_error, log_warning
from config import VOICE_RATE, VOICE_TIMEOUT, VOICE_LANGUAGE

# Initialize text-to-speech engine
engine = None
try:
    engine = pyttsx3.init()
    engine.setProperty('rate', VOICE_RATE)
    log_info("Text-to-Speech engine initialized")
except Exception as e:
    log_warning(f"TTS initialization warning: {str(e)[:100]}")
    engine = None

def speak(text, rate=1.0):
    """
    Convert text to speech
    
    Args:
        text (str): Text to speak
        rate (float): Speech rate multiplier (0.5 - 2.0)
    """
    try:
        if engine is None:
            log_warning("Text-to-Speech not available on this system")
            return False
        
        engine.setProperty('rate', VOICE_RATE * rate)
        engine.say(text)
        engine.runAndWait()
        log_info(f"Spoke: {text[:50]}...")
        return True
    except Exception as e:
        log_error(f"Speech error: {str(e)[:100]}")
        return False

def recognize_speech():
    """
    Recognize speech from microphone
    
    Returns:
        str: Recognized text or None
    """
    recognizer = sr.Recognizer()
    
    try:
        log_info("Listening...")
        with sr.Microphone() as source:
            st.info("Listening... Speak now! (10 seconds)")
            # Adjust for ambient noise
            recognizer.adjust_for_ambient_noise(source, duration=1)
            audio = recognizer.listen(source, timeout=VOICE_TIMEOUT)
        
        # Try Google Speech Recognition
        log_info("Processing audio...")
        text = recognizer.recognize_google(audio, language=VOICE_LANGUAGE)
        log_info(f"Recognized: {text}")
        st.success(f"You said: {text}")
        return text
        
    except sr.UnknownValueError:
        error_msg = "Could not understand audio. Please speak clearly and try again."
        log_warning(error_msg)
        st.error(error_msg)
        return None
    except sr.RequestError as e:
        error_msg = f"Speech service error: {str(e)[:100]}"
        log_error(error_msg)
        st.error(error_msg)
        return None
    except Exception as e:
        error_msg = f"Microphone error: {str(e)[:100]}"
        log_error(error_msg)
        st.error(error_msg)
        return None

def is_speech_available():
    """Check if speech features are available"""
    try:
        # Try to access microphone
        with sr.Microphone():
            return True
    except:
        return False
