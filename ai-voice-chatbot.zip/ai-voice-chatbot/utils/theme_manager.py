"""
Theme customization module for user-defined themes
"""

import json
import os
from config.config import DATA_DIR
from utils.logger import log_info, log_error

THEMES_FILE = os.path.join(DATA_DIR, "themes.json")

# Default themes
DEFAULT_THEMES = {
    "light": {
        "name": "Light",
        "primary_color": "#0066CC",
        "secondary_color": "#667eea",
        "accent_color": "#764ba2",
        "bg_color": "#FFFFFF",
        "text_color": "#333333",
        "chat_user_bg": "#E3F2FD",
        "chat_bot_bg": "#F5F5F5",
        "is_dark": False
    },
    "dark": {
        "name": "Dark",
        "primary_color": "#00D9FF",
        "secondary_color": "#667eea",
        "accent_color": "#764ba2",
        "bg_color": "#1E1E1E",
        "text_color": "#FFFFFF",
        "chat_user_bg": "#1A3A52",
        "chat_bot_bg": "#2D2D2D",
        "is_dark": True
    },
    "ocean": {
        "name": "Ocean",
        "primary_color": "#0077BE",
        "secondary_color": "#00D4FF",
        "accent_color": "#0096FF",
        "bg_color": "#E8F4F8",
        "text_color": "#003D5C",
        "chat_user_bg": "#B3E5FC",
        "chat_bot_bg": "#E0F7FA",
        "is_dark": False
    },
    "forest": {
        "name": "Forest",
        "primary_color": "#2D6A4F",
        "secondary_color": "#40916C",
        "accent_color": "#52B788",
        "bg_color": "#E8F5E9",
        "text_color": "#1B4332",
        "chat_user_bg": "#C8E6C9",
        "chat_bot_bg": "#F1F8E9",
        "is_dark": False
    },
    "sunset": {
        "name": "Sunset",
        "primary_color": "#FF6B6B",
        "secondary_color": "#FFA500",
        "accent_color": "#FFD700",
        "bg_color": "#FFF8F0",
        "text_color": "#8B4513",
        "chat_user_bg": "#FFE4E1",
        "chat_bot_bg": "#FFFACD",
        "is_dark": False
    }
}

def load_user_theme():
    """Load saved user theme"""
    try:
        if os.path.exists(THEMES_FILE):
            with open(THEMES_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return data.get('current_theme', 'light')
    except Exception as e:
        log_error(f"Error loading theme: {e}")
    return 'light'

def get_theme_settings(theme_name):
    """Get theme settings by name"""
    try:
        if os.path.exists(THEMES_FILE):
            with open(THEMES_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
                if theme_name in data.get('custom_themes', {}):
                    return data['custom_themes'][theme_name]
        
        # Return default theme
        return DEFAULT_THEMES.get(theme_name, DEFAULT_THEMES['light'])
    except Exception as e:
        log_error(f"Error getting theme settings: {e}")
        return DEFAULT_THEMES['light']

def save_custom_theme(theme_name, theme_data):
    """Save custom theme"""
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        
        # Load existing data
        themes_data = {"current_theme": "light", "custom_themes": {}}
        if os.path.exists(THEMES_FILE):
            with open(THEMES_FILE, 'r', encoding='utf-8') as f:
                themes_data = json.load(f)
        
        # Add new custom theme
        themes_data['custom_themes'][theme_name] = theme_data
        
        # Save
        with open(THEMES_FILE, 'w', encoding='utf-8') as f:
            json.dump(themes_data, f, indent=2, ensure_ascii=False)
        
        log_info(f"Custom theme saved: {theme_name}")
        return True
    except Exception as e:
        log_error(f"Error saving custom theme: {e}")
        return False

def set_current_theme(theme_name):
    """Set current active theme"""
    try:
        themes_data = {"current_theme": "light", "custom_themes": {}}
        if os.path.exists(THEMES_FILE):
            with open(THEMES_FILE, 'r', encoding='utf-8') as f:
                themes_data = json.load(f)
        
        themes_data['current_theme'] = theme_name
        
        with open(THEMES_FILE, 'w', encoding='utf-8') as f:
            json.dump(themes_data, f, indent=2, ensure_ascii=False)
        
        log_info(f"Theme changed to: {theme_name}")
        return True
    except Exception as e:
        log_error(f"Error setting theme: {e}")
        return False

def get_all_themes():
    """Get all available themes (default + custom)"""
    try:
        all_themes = DEFAULT_THEMES.copy()
        
        if os.path.exists(THEMES_FILE):
            with open(THEMES_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
                all_themes.update(data.get('custom_themes', {}))
        
        return all_themes
    except Exception as e:
        log_error(f"Error loading themes: {e}")
        return DEFAULT_THEMES

def get_theme_css(theme_name):
    """Generate CSS for theme"""
    theme = get_theme_settings(theme_name)
    
    css = f"""
    <style>
        :root {{
            --primary-color: {theme['primary_color']};
            --secondary-color: {theme['secondary_color']};
            --accent-color: {theme['accent_color']};
            --bg-color: {theme['bg_color']};
            --text-color: {theme['text_color']};
            --chat-user-bg: {theme['chat_user_bg']};
            --chat-bot-bg: {theme['chat_bot_bg']};
        }}
        
        body {{
            background-color: var(--bg-color);
            color: var(--text-color);
        }}
        
        .header-title {{
            color: var(--primary-color);
        }}
        
        .chat-message-user {{
            background-color: var(--chat-user-bg);
            border-left-color: var(--primary-color);
        }}
        
        .chat-message-bot {{
            background-color: var(--chat-bot-bg);
            border-left-color: var(--secondary-color);
        }}
        
        .stButton>button {{
            background-color: var(--primary-color);
            color: white;
        }}
        
        .stButton>button:hover {{
            background-color: var(--secondary-color);
        }}
        
        .support-panel {{
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
        }}
        
        .feature-box {{
            border-color: var(--primary-color);
            background: var(--bg-color);
        }}
    </style>
    """
    return css

def delete_custom_theme(theme_name):
    """Delete custom theme"""
    try:
        if os.path.exists(THEMES_FILE):
            with open(THEMES_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            if theme_name in data.get('custom_themes', {}):
                del data['custom_themes'][theme_name]
                
                with open(THEMES_FILE, 'w', encoding='utf-8') as f:
                    json.dump(data, f, indent=2, ensure_ascii=False)
                
                log_info(f"Custom theme deleted: {theme_name}")
                return True
        
        return False
    except Exception as e:
        log_error(f"Error deleting theme: {e}")
        return False
