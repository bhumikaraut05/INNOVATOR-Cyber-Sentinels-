"""
Source module initialization
"""

__version__ = "2.0.0"
__author__ = "AI Voice Chatbot Team"
__license__ = "MIT"

print("AI Voice Chatbot v2.0 loaded successfully!")
