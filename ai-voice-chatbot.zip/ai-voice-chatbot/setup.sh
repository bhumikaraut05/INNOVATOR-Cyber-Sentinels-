#!/bin/bash

# Setup script for AI Voice Chatbot

echo "🚀 Setting up AI Voice Chatbot..."
echo "=================================="

# Check Python version
python_version=$(python --version 2>&1)
echo "✅ $python_version"

# Create virtual environment
echo "📦 Creating virtual environment..."
python -m venv venv

# Activate virtual environment
echo "🔌 Activating virtual environment..."
source venv/bin/activate

# Install requirements
echo "📥 Installing dependencies..."
pip install -r requirements.txt

# Create data directories
echo "📁 Creating data directories..."
mkdir -p data logs

# Run application
echo "✨ Setup complete!"
echo "=================================="
echo "🎯 To run the app:"
echo "   streamlit run app.py"
